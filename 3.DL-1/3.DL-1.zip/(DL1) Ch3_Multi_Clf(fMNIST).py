#!/usr/bin/env python
# coding: utf-8
# %%

# %%
import tensorflow as tf
from tensorflow import keras
keras.__version__
import pandas as pd


# %%
fashion_mnist = tf.keras.datasets.fashion_mnist
(train_data0, y_train0), (test_data0, y_test0) = fashion_mnist.load_data()

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']


# %%
# 데이타 모양을 2차원 이미지에서 1차원 으로 변경
# 모든 값을 0과 1 사이로 스케일을 조정
train_images = train_data0.reshape((60000, 28 * 28))
train_images = train_images.astype('float32') / 255
test_images = test_data0.reshape((10000, 28 * 28))
test_images = test_images.astype('float32') / 255


# %%
from sklearn.model_selection import train_test_split
x_train, x_test, y_train_, y_test_ = train_test_split(train_images, y_train0, train_size=.9, random_state=0, shuffle=True)


# %%
# categorical
from tensorflow.keras.utils import to_categorical
y_train = to_categorical(y_train_)
y_test = to_categorical(y_test_)

# %%
# 45000 : 9000 분할
x_val = x_train[:45000]
partial_x_train = x_train[45000:]

y_val = y_train[:45000]
partial_y_train = y_train[45000:]


# %%
# 낮은용량 모델과 높은 용량 모델을 실험
from tensorflow.keras import models
from tensorflow.keras import layers

model = models.Sequential()

# # 낮은 용량 모델(50K 파라메터)
# model.add(layers.Dense(64, activation='relu', input_shape=(28 * 28,)))
# model.add(layers.Dense(64, activation='relu'))
# 두배 용량 파라메터
model.add(layers.Dense(128, activation='relu', input_shape=(28 * 28,)))
model.add(layers.Dense(128, activation='relu'))
model.add(layers.Dense(10, activation='softmax'))    # 바뀜.  10개의 벡터출력, 활성함수 : softmax

model.summary()


# %%
# (분석)
# * 마지막 `Dense` 층의 크기는 10 : 각 입력 샘플에 대해서 10차원의 벡터를 출력
# * 이 벡터의 각 원소(각 차원)은 각기 다른 출력 클래스의 예측값이 인코딩 되어있음.
# * 마지막 층에 `softmax` 활성함수 : 입력 샘플당 10개의 출력 클래스에 대한 확률 분포를 출력 -->


# %%
# 손실함수만 바꾸어주면 됨.
model.compile(optimizer='rmsprop',
              loss='categorical_crossentropy',  # 손실함수만 바뀜.
              metrics=['accuracy']
             )

# %%
history = model.fit(partial_x_train,
                    partial_y_train,
                    epochs=20,
                    batch_size=32,
                    validation_data=(x_val, y_val))


# %%
history_dict = history.history
history_dict.keys()


# %%
# 훈련과 검증 데이터에 대한 손실
import matplotlib.pyplot as plt

acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(1, len(acc) + 1)    # [0~19] --> [1~20]

plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

plt.show()


# %%
# 훈련과 검증 데이터에 대한 정확도

plt.clf()   # 그래프를 초기화
acc = history_dict['accuracy']
val_acc = history_dict['val_accuracy']

plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.show()


# ## 훈련된 모델로 새로운 데이터에 대해 예측하기

# %%
# predict : 10개의 확률 반환
pred = model.predict(x_test)

print(f'예측 갯수 : {pred.shape}')
pred[:5]


# %%
import numpy as np
# 예측값 정리
pred2 = [np.argmax([x]) for x in pred]     # 확률이 가장 높은 열 선택
# np array 변환
pred2 = np.array(pred2)

y2 = [np.argmax([x]) for x in y_test]
y2 = np.array(y2)


# %%
# categorical
f'맞춘 비율 : {np.mean(pred2 == y2):.4f}'


# %%
model.evaluate(x_test, y_test)

# %%
np.asarray(class_names)[pred2]

# %% [markdown]
#
# ### 연습
# #### 
# #### * 은닉층변경하고 검증과 테스트 정확도에 어떤 영향을 미치는지 확인.
# #### * 은닉 유닛 갯수 변경.
# #### * 훈련세트 크게 , 검증세트 줄여서.
#
#


# %%
