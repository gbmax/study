#!/usr/bin/env python
# coding: utf-8
# %% [markdown]
# #### 첫 예제
# ##### MNIST 데이타로 숫자 맞추기

# %%
from tensorflow.keras.datasets import mnist

(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

# %%
import matplotlib.pyplot as plt

digit = train_images[4]

plt.imshow(digit, cmap=plt.cm.binary)
plt.show()

# %%
from tensorflow.keras import models
from tensorflow.keras import layers

network = models.Sequential()
network.add(layers.Dense(512, activation='relu', input_shape=(28 * 28,)))
network.add(layers.Dense(10, activation='softmax'))

# %%
network.compile(optimizer='rmsprop',
                loss='categorical_crossentropy',
                metrics=['accuracy'])

# %% [markdown]
# 모든 값을 0과 1 사이로 스케일을 조정.  
# `uint8` 타입의 `(60000, 28, 28)` -->  0과 1 사이의 값을 가지는 `float32` 타입의 `(60000, 28 * 28)` 크기의 배열로 바꿈.

# %%
train_images = train_images.reshape((60000, 28 * 28))
train_images = train_images.astype('float32') / 255

test_images = test_images.reshape((10000, 28 * 28))
test_images = test_images.astype('float32') / 255

# %% [markdown]
# 레이블을 범주형으로 인코딩

# %%
from tensorflow.keras.utils import to_categorical

train_labels = to_categorical(train_labels)
test_labels = to_categorical(test_labels)

# %%
network.fit(train_images, train_labels, epochs=5, batch_size=128)

# %%
test_loss, test_acc = network.evaluate(test_images, test_labels)

# %%
print('test_acc:', test_acc)

# %%

# %% [markdown]
# #### 학습과정 보기
# ##### [1,2,3] 예측에서 초기값으로부터 정답(기울기=1)을 찾아가는 과정 보여주기.
#

# %%

# 학습률 메모 
# 1,2,3 예제 : 0.15 수렴, 0.2 발산
# [2,4,5] 예제 : 0.05 수렴, 1 발산
import tensorflow as tf
import tensorflow.keras as keras
import numpy as np
# from tensorflow.keras.callbacks import LambdaCallback
import matplotlib as mpl
mpl.rcParams['axes.unicode_minus'] = False


# %%
tf.__version__


# %%

def model_fit(X, y, epochs):
    model = keras.Sequential()
    model.add(keras.layers.Dense(1, input_shape=(len(x[0]),)))
    # model.add(keras.layers.Dense(1))
    # 0.1 : 느림, 0.2 : 발산, 0.15 : 수렴.
    model.compile(optimizer=keras.optimizers.SGD(lr), loss=keras.losses.mse)

    # w, bias 수집을 위한 콜백 정의. weights_dict에 bias도 같이 저장됨.
    weights_dict = {}
    save_weights = tf.keras.callbacks.LambdaCallback     ( on_epoch_end=lambda epoch, logs: weights_dict.update( {epoch:model.get_weights()} ) )
    callbacks = [save_weights]

    # loss 수집을 위한 콜백 정의
    loss_dict = {}
    save_loss = tf.keras.callbacks.LambdaCallback     (on_epoch_end=lambda epoch, logs: loss_dict.update({epoch:logs['loss']}))
    callbacks = [save_weights, save_loss]

    history = model.fit( x, y, epochs=epochs, callbacks=callbacks, verbose=0 )
    return weights_dict, loss_dict, model, history


# %%

x = [[1], [2], [3]]
y = [1, 2, 3]
ex = [5]
lr = 0.15
lr= 0.2
# x = [[2,4,5], [5,2,8], [2,2,1], [4,2,2], [6,2,2], [3,1,1], [5,3,4], [1,8,1]]
# y = [1, -1, 3, 4, 6, 3, 4, 8]
# ex = [12,4,5]
# lr = 0.05

epochs = 50
weights_dict, loss_dict, model, history = model_fit(x,y, epochs)


# %%
model.predict([ex])


# %%
f'{ex} 예측값 : {model.predict([ex])[0][0]}'


# %%

# [2, 4, 5] 예제는 1 노드에 weight 갯수가 3 이므로 적용안됨.
import pandas as pd
# weight, bias 정보 가공
wb = pd.DataFrame(weights_dict)
w, b = wb.iloc[0, :], wb.iloc[1,:]

w = np.array([i.item() for i in w])   # [[]] 형식을 풀어줌.
# 손실값
loss = list(loss_dict.values())

# 그래프에서 잘 식별되도록 w, loss 최소, 최대값을 실제값보다 10% 크게 함.
loss = np.array(loss)
w_band, loss_band = w.max() - w.min(), loss.max() - loss.min()
w_min, w_max = w.min() - w_band * 0.1, w.max() + w_band * 0.1
loss_min, loss_max = loss.min() - loss_band * 0.1, loss.max() + loss_band * 0.1


# %%

# w 에 따른 loss 변화를 scatter plot으로.
import matplotlib.pyplot as plt
fig,ax = plt.subplots(1,2, figsize=(10, 5))
for i in range(epochs):
    ax[0].scatter(w, loss )
    ax[0].set_xlabel('W'), ax[0].set_xlim(w_min, w_max)
    ax[0].set_ylabel('loss'), ax[0].set_ylim(loss_min, loss_max)

for i in range(epochs):
    ax[1].plot(w, loss )
    ax[1].set_xlabel('W'), ax[1].set_xlim(w_min, w_max)
    ax[1].set_ylabel('loss'), ax[1].set_ylim(loss_min, loss_max)

out_arr = np.argsort(w)
ax[0].plot(w[out_arr], loss[out_arr])
ax[1].plot(w[out_arr], loss[out_arr])

fig.suptitle('w - loss plot by epochs', fontsize=14)  # subplot 있을 때 대표제목
plt.show()


# %%
# epoch 별로 정답을 찾아가는 모델변화를 보여줌.
plt.subplots(figsize=(7, 5))
plot_x = np.arange(-10,10)
for i in range(epochs):
    plot_y = plot_x * w[i] + b[i]
    plt.plot(plot_x, plot_y)
    plt.xlim(0, 10), plt.ylim(0, 10)
plt.show()
# %% [markdown]
# ### (dl) $ pip install ipympl 필요할 수 있음.
# %%
# 변화를 animation으로 보여줌.
# set the ipympl backend
# %matplotlib widget
from matplotlib.animation import FuncAnimation
from IPython import display
plt.rcParams['animation.ffmpeg_path'] = 'ffmpeg'

f,ax = plt.subplots(1,2, figsize=(10, 5))

x = range(epochs)
y = w

def update(frame):  # 시간간격으로 plot 하는 콜백함수 정의
    ax[0].clear(), ax[1].clear()   # 다시 그리면서 색이 임의로 바뀌는 것 방지.(기본색(파랑) 항상 사용)
    ax[0].set_xlabel('W'), ax[0].set_ylabel('loss')
    ax[1].set_xlabel('epochs'), ax[1].set_ylabel('w')

    ax[0].set_xlim(w_min, w_max), ax[0].set_ylim(loss_min, loss_max)
    ax[1].set_xlim(0, epochs), ax[1].set_ylim(w_min, w_max)

    ax[0].scatter(w[:frame], loss[:frame])
    ax[0].plot(w[:frame], loss[:frame])

    # ax[1].cla()
    ax[1].plot(x[:frame], y[:frame])

ax[0].set_title('w - loss by epochs')
ax[1].set_title('w by epochs')

# 콜백함수 호출
ani = FuncAnimation( fig=f, func=update, frames=epochs,  blit=False, repeat=False, interval = 500 )

display.display(display.HTML(ani.to_jshtml()))

# video = ani.to_html5_video()
# html = display.HTML(video)
# display.display(display.HTML(video))
plt.close()                   # avoid plotting a spare static plot
# plt.show()
# %%


# %%
# epoch 에 따라 정답 착아가는 직선 보여줌.
f, ax = plt.subplots(figsize=(7, 5))

x = np.arange(0,10)
ax.set_xlim(0, 5), ax.set_ylim(0, 5)

def update(frame):
    ax.clear()
    ax.set_xlabel('x'), ax.set_ylabel('y')
    ax.plot([0,5], [0, 5], lw=0.5, ls='--', c='r')
    ax.set_xlim(0, 5), ax.set_ylim(0, 5)
    y = x * w[frame] + b[frame]
    ax.plot(x, y)
ani2 = FuncAnimation( fig=f, func=update, frames=epochs,  blit=False, repeat=False, interval = 500 )
display.display(display.HTML(ani2.to_jshtml()))

# video = ani2.to_html5_video()
# html = display.HTML(video)
# display.display(display.HTML(video))
plt.close()                   # avoid plotting a spare static plot
# plt.show()


# %%




