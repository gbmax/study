#!/usr/bin/env python
# coding: utf-8
# %%

# %%
import tensorflow as tf
from tensorflow import keras
keras.__version__
import pandas as pd


# %%
# 패션-MNIST 샘플 (Zalando, MIT License)


# %%

fashion_mnist = tf.keras.datasets.fashion_mnist
(train_data0, y_train0), (test_data0, y_test0) = fashion_mnist.load_data()

class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# from tensorflow.keras.utils import to_categorical
# y_train = to_categorical(y_train0)
# y_test = to_categorical(y_test0)


# %%
# label = 0, 1 인 이미지와 레이블 정보만 추출
import numpy as np
idx = np.where((y_train0 == 2) | (y_train0 == 3))

images = train_data0[idx]
labels0 = y_train0[idx]


# %%
np.asarray(class_names)[labels0[:10]]


# %%
# 샘플 이미지 보기
import matplotlib.pyplot as plt
plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.imshow(images[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[labels0[i]])
plt.show()


# %%
# labels : 1,2 는 시스템상에서 항상 True로 인식함.
labels = labels0 == 2

# 데이타 모양을 2차원 이미지에서 1차원 으로 변경
# 모든 값을 0과 1 사이로 스케일을 조정
train_images = images.reshape((12000, 28 * 28))
train_images = train_images.astype('float32') / 255


# %%
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(train_images, labels, train_size=.9, random_state=0, shuffle=True)


# %%
x_train.shape


# %%
# X_train 데이타를 학습, 검증 세트로 나눔.

x_val = x_train[:5000]
partial_x_train = x_train[5000:]

y_val = y_train[:5000]
partial_y_train = y_train[5000:]


# %%
from tensorflow.keras import models, layers

model = models.Sequential()
model.add(layers.Dense(64, activation='relu', input_shape=(28 * 28, )))
model.add(layers.Dense(128, activation='relu'))

model.add(layers.Dense(1, activation='sigmoid'))


# %%
# 손실 함수와 옵티마이저를 선택.
# 이진 분류 문제이고 신경망의 출력이 확률
#   - 네트워크의 끝에 시그모이드 활성화 함수를 사용한 하나의 유닛으로 된 층  
#   - `binary_crossentropy` 손실이 적합 (`mean_squared_error`를 사용할 수도 있으나 최적이 아님)

model.compile(optimizer='rmsprop',
              loss='binary_crossentropy',
              # loss='MSE',
              metrics=['accuracy'])

# %% [markdown]
# #### 훈련 및 검증
#


# %%
from keras.utils.vis_utils import plot_model
plot_model(model, show_shapes=True)


# %%
history = model.fit(partial_x_train,
                    partial_y_train,
                    epochs=40,
                    batch_size=128,
                    validation_data=(x_val, y_val))


# %% [markdown]
# ####  테스트셋으로 검증
#

# %%
score1 = model.evaluate(x_test, y_test)
print(f'loss : {score1[0]}, accuracy : {score1[1]}')

# %%
history_dict = history.history
history_dict.keys()


# %%
# 훈련과 검증 데이터에 대한 손실과 정확도

import matplotlib.pyplot as plt

acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(1, len(acc) + 1)    # [0~19] --> [1~20]

plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

plt.show()


# %% [markdown]
# ###  (분석)
# #### 점선은 훈련 손실과 정확도이고 실선은 검증 손실과 정확도(무작위한 초기화 때문에 결과가 조금 다를 수 있음)
# #### 훈련 손실이 에포크마다 감소하고 훈련 정확도는 에포크마다 증가
# #### 과대적합 - 검증 손실과 정확도는 4번째 에포크에서 역전

# %%
plt.clf()   # 그래프를 초기화합니다
acc = history_dict['accuracy']
val_acc = history_dict['val_accuracy']

plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

plt.show()

# %%
#### 최종 모델 만들기(epoch=3 또는 epoch = 4 ?)
history = model.fit(partial_x_train, partial_y_train,
                    epochs=6,
                    batch_size=32,
                    validation_data=(x_val, y_val))

# %% [markdown]
# #### 테스트셋으로 검증

# %%
score2 = model.evaluate(x_test, y_test)
print(f'loss : {score2[0]}, accuracy : {score2[1]}')

# %%
# score1 : 40epoch model의 성능.
# score2 : 튜닝된 모델의 성능
score1, score2

# %% [markdown]
# #### 훈련된 모델로 새로운 데이터에 대해 예측하기

# %%
pred = np.round(model.predict(x_test[:10])).astype(int)
pred = pred.flatten()
pred


# %%
# list 는 np array로 바꾸어야 ...
np.asarray(class_names)[pred]


# %%
np.asarray(class_names)[y_test[:10]]


# %%
pred == y_test[:10]

# %% [markdown]
# ### 연습
# # 
# #### * 두 개의 은닉층을 사용하고 검증과 테스트 정확도에 어떤 영향을 미치는지 확인.
# #### * 층의 은닉 유닛 갯수 변경: 많게, 적게.
# #### * `relu` 대신에 `sigmoid, tanh` 활성화 함수(초창기 신경망에서 인기 있었던 함수) 사용.

# %%
